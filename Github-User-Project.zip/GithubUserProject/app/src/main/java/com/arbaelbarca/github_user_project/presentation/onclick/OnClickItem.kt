package com.arbaelbarca.github_user_project.presentation.onclick

interface OnClickItem {
    fun clickItem(any: Any, pos: Int)
}